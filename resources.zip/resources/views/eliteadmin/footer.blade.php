<footer class="footer">
    © 2021 Centro Comercial José Luis
</footer>