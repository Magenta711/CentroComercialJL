<header id="header">
    <img src="{{asset('img/pages/'.$img)}}" alt="" width="100%">
</header>