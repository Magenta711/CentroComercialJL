<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialMediaRents extends Model
{
    protected $fillable = ['rent_id','link','type'];
}
