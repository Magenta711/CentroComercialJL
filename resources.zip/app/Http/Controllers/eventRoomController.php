<?php

namespace App\Http\Controllers;

use App\EventRoom;
use Carbon\Carbon;
use Illuminate\Http\Request;

class eventRoomController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('verified');
        $this->middleware('permission:Lista de administración de eventos del salon|Crear eventos del salon|Ver eventos del salon|Editar eventos del salon|Eliminar eventos del salon', ['only' => ['index']]);
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = EventRoom::whereDate('start', '>=', $request->start)->whereDate('end',   '<=', $request->end)->get(['id', 'title', 'start', 'end']);
            return response()->json($data);
        }
        return view('admin.event_room.index');
    }

    public function store(Request $request)
    {
        $event = EventRoom::create($request->all());
        return response()->json( $event );
    }

    public function update(Request $request,EventRoom $id)
    {
        $id->update($request->all());
        return response()->json( $id );
    }
    
    public function destroy(EventRoom $id)
    {
        $id->delete();
        return response()->json( ['succes' => 'Se el elimino el evento ' .$id->id ]);
    }
}
